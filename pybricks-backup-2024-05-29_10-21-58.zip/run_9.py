from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, run_task, multitask

#------------------------------------------
# Code for the robot
#------------------------------------------
class run9():

    def run(self, bumblebee = DriveBase, front_motor = Motor, back_motor = Motor):
        #------------------------------------------
        # Code for the robot
        #------------------------------------------
        #bumblebee.settings(turn_acceleration=300,turn_rate=200)
        #bumblebee.settings(straight_speed=400,straight_acceleration=600)
        bumblebee.straight(249) # move forward 
        bumblebee.turn(-43) ## turn towards mission 01
        bumblebee.straight(125) # move towards mission 01
        front_motor.run_angle(500,-390) # push down the activator for mission1
        bumblebee.straight(-66)  # move back from mission 1
        front_motor.run_angle(500,390) # pull up the front arm back 
        bumblebee.settings(turn_acceleration=200,turn_rate=100)
        bumblebee.turn(70) # turn right 
        bumblebee.straight(440) # travel towards the mission 2
        bumblebee.turn(-62)  # turn towards mission 2
        bumblebee.settings(straight_speed=200,straight_acceleration=200) # from 250 to 200
        bumblebee.straight(65) # push forward to push the mission 2 once
        bumblebee.straight(-65) # push backword to push the mission 2 
        bumblebee.straight(65) # push forward to push the mission 2 2nd time
        bumblebee.straight(-30) # push backword to turn towards same
        bumblebee.turn(15) # slight turn right towards sam
        bumblebee.straight(100) #move forward towards Sam
        front_motor.run_angle(500,-370) # lower down the arm to secure sam
        bumblebee.straight(-85) # move backwards from 95 to 85
        bumblebee.turn(50) # position robot before dropping the audience member
        back_motor.run_angle(400,-250) #drop audience member
        bumblebee.settings(straight_speed=800,straight_acceleration=800)
        #increase the speed to move faster to home 
        
        back_motor.run_angle(400,260) # raise bumblebee attachment 
        bumblebee.turn(-45) # turn left before moving back home
        
        bumblebee.curve(-1000,-40,Stop.COAST) #Use a curve back home

        front_motor.run_angle(500,370) #raise arm to retrieve Sam 
        wait(700)
        front_motor.run_angle(500,-370) # lower the arm down
        
        bumblebee.settings(300,1000,200,800) # Reset the speed settings to default
        #---------------------------------
        #=Code Finished=
        #---------------------------------