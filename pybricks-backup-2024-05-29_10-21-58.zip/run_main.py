from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, hub_menu, multitask, run_task

#from run_1_05_04 import run1
from run_1_10_05 import run1
from run_2_05_04 import run2
from run_3_18_05 import run3
#from run_3_24_05 import run3

from run_4_05_04 import run4
from run_5_05_04 import run5
from run_6_05_04 import run6
from run_7_05_04 import run7
from run_8_07_04 import run8
from run_9duplicate import run9

#Initialize the PrimeHub as hub
hub = PrimeHub()

#Initialisate the robot 
# Step 1 - Initialize the drive base 
# Step 2 - Initialize the front and back motors 
# Step 3 - Initialize the left and right color sensors in the front
#---------------------------------------------------------------------

# Initialize both motors. In this example, the motor on the
# left must turn counterclockwise to make the robot go forward.
left_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.A)

# Initialize the drive base. 
# In our robot, the wheel diameter is 88mm.
# The distance between the two wheel-ground contact points is 145mm.
bumblebee = DriveBase(left_motor, right_motor, wheel_diameter=88, axle_track=145)
# Optionally, uncomment the line below to use the gyro for improved accuracy.
bumblebee.use_gyro(True)

#Initialize the front and back motors 
front_motor = Motor(Port.D)
back_motor = Motor(Port.C)

# Initialize the color sensors.
right_sensor = ColorSensor(Port.F)
left_sensor = ColorSensor(Port.E)
#Create the instances of each run 
run1 = run1()
run2 = run2()
run3 = run3()
run4 = run4()
run5= run5()
run6 = run6()
run7 = run7()
run8 = run8()
run9 = run9() # run2 alternate two times stage theatre scene change
    

# Let's offer these menu options. You can add as many as you like.
menu_options = ("1", "2", "3", "4", "5", "6", "7", "8", "9")
menu_index = 0


while True:

    # Normally, the center button stops the program. But we want to use the
    # center button for our menu. So we can disable the stop button.
    hub.system.set_stop_button(None)

    while True:
        #Display the current program based on the menu_index variable
        hub.display.char(menu_options[menu_index])

        # Wait for any button.
        pressed = ()
        while not pressed:
            pressed = hub.buttons.pressed()
            wait(10)
        
        # Wait for the button to be released.
        while hub.buttons.pressed():
            wait(10)

        # Now check which button was pressed.
        if Button.CENTER in pressed:
            # Center button,  exit the inner loop and run the selected program
            break
        elif Button.LEFT in pressed:
            # Left button, so decrement menu menu_index.
            menu_index = (menu_index - 1) % len(menu_options)
        elif Button.RIGHT in pressed:
            # Right button, so increment menu menu_index.
            menu_index = (menu_index + 1) % len(menu_options) 
                

    # Now we want to use the Center button as the stop button again.
    hub.system.set_stop_button(Button.CENTER)

    # Based on the selection, choose a program.
    selected = menu_options[menu_index]
    if selected == "1":
        run1.run(bumblebee, front_motor,back_motor) 
        menu_index = 1 # increase the menu index to point to next program
    elif selected == "2":
        run2.run(bumblebee, front_motor, back_motor)
        menu_index = 2
    elif selected == "3":
        run3.run(bumblebee, front_motor, back_motor)
        menu_index = 3
    elif selected == "4":
        run4.run(bumblebee, front_motor, back_motor)
        menu_index = 4
    elif selected == "5":
        run5.run(bumblebee, front_motor, back_motor)
        menu_index = 5
    elif selected == "6":
        run6.run(bumblebee, front_motor, back_motor)
        menu_index = 6
    elif selected == "7":
        run7.run(bumblebee, front_motor, back_motor)
        break
    elif selected == "8":
        run8.run(bumblebee, front_motor, back_motor) # run to flick Izzy if run 3 fails
        menu_index = 5 ##point back to run 6 
    elif selected == "9":
        run9.run(bumblebee,front_motor,back_motor)
        menu_index = 2 ## poinnt back to run 3

