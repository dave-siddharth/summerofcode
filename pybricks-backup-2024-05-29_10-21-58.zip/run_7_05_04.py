from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
#------------------------------------------
# Code for the robot
#------------------------------------------

# Run 7
# Below code is to complete the mission number
# Mission start
# ===============================================
class run7():
#------------------------------------------
# Code for the robot
#------------------------------------------
    def run(self, bumblebee = DriveBase, front_motor = Motor, back_motor = Motor):
        bumblebee.straight(500) #forward 500mm
        bumblebee.turn(-43) #turn 43 degrees
        bumblebee.straight(260) # drive forward 260mm
        bumblebee.turn(88) #turn 88 degrees to face m07/m06
        bumblebee.straight(145) #head towards the mission model
        front_motor.run_angle(500,-600)  # rotate front motor to complete speakers
        bumblebee.straight(-200) #reverse backwards 200 mm to complete lights
        #bumblebee.turn(45)
        #bumblebee.straight(-100)
        #bumblebee.turn(-90)
        #bumblebee.straight(100)
        bumblebee.settings(307,1152,202,910) # Reset the speed settings to default