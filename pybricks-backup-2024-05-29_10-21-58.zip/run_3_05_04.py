from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, hub_menu, multitask, run_task

class run3():
#------------------------------------------
# Code for the robot
#------------------------------------------
    def run(self, bumblebee = DriveBase, front_motor = Motor, back_motor = Motor):

        #------------------------------------------
        # Code for the robot
        #-----------------------------------------
        #move for 10cm
        bumblebee.settings(turn_rate=150,turn_acceleration=600)
        bumblebee.straight(110)
        #turn right 42 degrees
        bumblebee.turn(35) ## reducing from 38 to 32
        #Move towards sound mixer
        bumblebee.straight(305)

        #Default speed settings for the bumblebee (307,1152,202,910)
        #Reduce the straight and turn speed + acceleration to improve accuracy
        
        #bumblebee.curve(72,20) #Move 20 degrees for a radius of 72mm
        #front_motor.run_angle(200,220) # run 200 deg/sec for 220 degrees
        async def curve_and_lift ():
            await multitask(front_motor.run_angle(350,160),bumblebee.curve(72,20))
        
        #bumblebee.settings(turn_rate=50,turn_acceleration=100)
        bumblebee.settings(straight_speed=100,straight_acceleration=40)
        run_task(curve_and_lift())

        ##mimic the action of pushing up, moving forward - do this two times to lift
        #the sound mixer
        ##front_motor.run_angle(200,100) #test 120 to 100
        ##bumblebee.straight(10) # reducing this a bit from 15 to 10 
        ##front_motor.run_angle(200,120)
        ##bumblebee.straight(15)
        #Now slowly turn the sound mixer so that the middle control can stay 
        ##bumblebee.settings(turn_rate=40,turn_acceleration=40)
        ##bumblebee.turn(20) # from 16 to 20
        ##wait(750) # was 400 before 

        bumblebee.settings(straight_speed=200,straight_acceleration=800)
        bumblebee.straight(-80) 
        bumblebee.settings(turn_rate=150,turn_acceleration=600)
        bumblebee.turn(33) 
        bumblebee.straight(430) ## 430 from 390
        bumblebee.turn(90)
        bumblebee.straight(120) ## approach the camera
        front_motor.run_angle(200,-150) # Reduced to 140 from 160 degrees 23 march

        #slow speed to move backwards and slow turn
        bumblebee.settings(straight_speed=100,straight_acceleration=600)
        bumblebee.settings(turn_rate=80,turn_acceleration=300)
        bumblebee.straight(-52) # move back from the camera bit - it was-50
        bumblebee.turn(71) # Reduced fro 71 to 65

        ##move back and raise the arm at the same time to save some time 
        async def backwards_and_raise_arm():
            await multitask(front_motor.run_angle(500,240),bumblebee.straight(-60))

        run_task(backwards_and_raise_arm())

        #set to original value
        #bumblebee.settings(straight_speed=200,straight_acceleration=800)
        bumblebee.settings(turn_rate=100,turn_acceleration=450)
        bumblebee.turn(-150) # was 130 earlier
        #Drop the two audience members mid way in the run 
        bumblebee.straight(175) # reduced by 10 mm from 240 to see if accuracy improves

        #### Drive base turn to straighten before dropping mini figures 
        back_motor.run_angle(400,-250) # Negative value of angle means move arm DOWN
        back_motor.run_angle(400,250) # Negative value of angle means move arm DOWN

        #slow down to increase the accuracy of the movement towards the expert
        bumblebee.settings(straight_speed=200,straight_acceleration=600) #was 300 before
        bumblebee.settings(turn_rate=60,turn_acceleration=100)
        bumblebee.turn(7) # turn to point to expert Emily (was 10 degrees)
        bumblebee.straight(240) # was 180mm
        bumblebee.turn(-54) # was 57 before
        ##collect and secure Izzy the skateboarder expert
        bumblebee.straight(170)
        front_motor.run_angle(500,-200) # Increased the speed from 150 mm/s to 500 mm/s
        bumblebee.straight(-40) # was 44 before
        front_motor.run_angle(150,-70) # keep the slow speed here 

        #bumblebee.turn(44) # was 40 before

        #bumblebee.settings(straight_speed=600,straight_acceleration=1200)
        #Drive the robot back to left area 
        #bumblebee.straight(-590)
        #bumblebee.turn(35) ## reduced from 40 to 30 on 25 03
        #bumblebee.curve(-380,120,Stop.COAST)
        front_motor.run_angle(500,270) #raise arm to retrieve Emily quickly 
        wait(1000) # give some time for technician to pick up Emily
        front_motor.run_angle(500,-270) # lower the arm down
        #bumblebee.settings(307,1152,202,910) # Reset the speed settings to default