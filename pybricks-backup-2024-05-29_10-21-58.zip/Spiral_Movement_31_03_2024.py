#------------------------------------
# <Spiral_Movement_Fibonacci>
# Author: [Siddharth Dave]
# Date: [31/03/2024]
# Description: This program demonstrates a sprial via the use of the Fibonacci Sequence
# Hardware: Spike Prime ADB with two color sensors, two attachment motors, two driving motors
# Software: PyBricks MicroPython <v3.4.1 Beta>
# Website: [https://wikipedia.org, https://chatgpt.com]
#--------------------------------------------------
from pybricks.hubs import PrimeHub, 
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from umath import cos, sin, radians
hub = PrimeHub()

#Initialisate the robot 
# Step 1 - Initialize the drive base 
# Step 2 - Initialize the front and back motors 
# Step 3 - Initialize the left and right color sensors in the front
#---------------------------------------------------------------------

# Initialize both motors. In this example, the motor on the
# left must turn counterclockwise to make the robot go forward.
left_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.A)

# Initialize the drive base. 
# In our robot, the wheel diameter is 88mm.
# The distance between the two wheel-ground contact points is 145mm.
bumblebee = DriveBase(left_motor, right_motor, wheel_diameter=88, axle_track=145)
# Optionally, uncomment the line below to use the gyro for improved accuracy.
bumblebee.use_gyro(True)

#Initialize the front abnd back motors 
front_motor = Motor(Port.D)
back_motor = Motor(Port.C)

# Initialize the color sensors.
right_sensor = ColorSensor(Port.F)
left_sensor = ColorSensor(Port.E)


# Set up parameters
fibonacci_count = 100
fibonacci_sequence = [0, 1]

# Generate Fibonacci sequence
while len(fibonacci_sequence) < fibonacci_count:
    next_fibonacci = fibonacci_sequence[0] + fibonacci_sequence[1]
    fibonacci_sequence.append(next_fibonacci)

# Golden ratio
golden_ratio = (1 + 5 ** 0.5) / 2

# Starting position
x, y = 0, 0

# Draw the spiral
for i in range(1, fibonacci_count):
    r = fibonacci_sequence[i] * golden_ratio
    theta = i * radians(137.508)
    
    # Calculate next position
    next_x = x + r * cos(theta)
    next_y = y + r * sin(theta)
    

    bumblebee.move(next_x * 10, next_y * 10)
    
    # Update current position
    x, y = next_x, next_y

# Beep to signal completion
hub.light_matrix.show_image('YES')

