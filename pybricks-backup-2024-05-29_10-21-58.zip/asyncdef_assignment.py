# <Async_def>
# Author: [Siddharth Dave]
# Date: [Current Date]
# Description: This program demonstrates the use of the async_def function
# Hardware: Spike Prime ADB with two color sensors, two attachment motors, two driving motors
# Software: PyBricks MicroPython <3.4.1 Beta>
# Website: [education.lego.com]

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, run_task, multitask

hub = PrimeHub()
#Initialisate the robot 
# Step 1 - Initialize the drive base 
# Step 2 - Initialize the front and back motors 
# Step 3 - Initialize the left and right color sensors in the front
#---------------------------------------------------------------------

# Initialize both motors. In this example, the motor on the
# left must turn counterclockwise to make the robot go forward.
left_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.A)

# Initialize the drive base. 
# In our robot, the wheel diameter is 88mm.
# The distance between the two wheel-ground contact points is 145mm.
bumblebee = DriveBase(left_motor, right_motor, wheel_diameter=88, axle_track=145)
# Optionally, uncomment the line below to use the gyro for improved accuracy.
bumblebee.use_gyro(True)

#Initialize the front abnd back motors 
front_motor = Motor(Port.D)
back_motor = Motor(Port.C)

# Initialize the color sensors.
right_sensor = ColorSensor(Port.F)
left_sensor = ColorSensor(Port.E)

#======================================
#Code for the robot
#======================================
## Part 1 - sequential code with hard coded values 

#bumblebee.settings(straight_speed=600, straight_acceleration=456)
#back_motor.run_angle(500,-1650)
#front_motor.run_angle(400,-250)
#bumblebee.straight(578)

## Part 1A - Converting sequential tasks to multi task using async def
#async def front_and_back():
 #   await multitask(back_motor.run_angle(500,-1650),front_motor.run_angle(400,-250), bumblebee.straight(700))                                                    

#run_task(front_and_back()) 

## Part 2
# Using variables in the function
front_motor_speed = 900 
front_motor_angle = 150
back_motor_speed = 900
back_motor_angle = 150
linear_distance = 500
linear_speed = 150
linear_acceleration = 200

bumblebee.settings(straight_speed=linear_speed,straight_acceleration=linear_acceleration)
bumblebee.straight(linear_distance)
## Part 1A - Converting sequential tasks to multi task using async def
async def front_and_back():
    bumblebee.settings(straight_speed=linear_speed,straight_acceleration=linear_acceleration)
    bumblebee.settings(turn_acceleration=80,turn_rate=80)
    await multitask(back_motor.run_angle(back_motor_speed,back_motor_angle),front_motor.run_angle(front_motor_speed,front_motor_angle), bumblebee.turn(180))
    await multitask(back_motor.run_angle(back_motor_speed,-back_motor_angle),front_motor.run_angle(front_motor_speed,-front_motor_angle), bumblebee.turn(180))

run_task(front_and_back())  #spin light show and front arm moves down

#Remember to set the straight_speed and straight_acceleration values for next robot movement
#bumblebee.settings(straight_speed=linear_speed,straight_acceleration=linear_acceleration)
