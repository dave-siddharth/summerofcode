from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, hub_menu, multitask, run_task


#----------------------------------
#Masterpiece,Expert,Audience Member
#----------------------------------
class run1():
    
    def run(self, bumblebee = DriveBase, front_motor = Motor, back_motor = Motor):
        #Drive the robot to drop the art piece and museum director
        bumblebee.straight(345) #start from home area
        #Reduce the turn speed to improve accuracy
        bumblebee.settings(turn_rate=80,turn_acceleration=300)
        bumblebee.turn(-57) # slow turn towards museum area - was 56 
        bumblebee.straight(900) #drop Anna,Masterpiece, one audience member

        #---------------------------------
        #M11 light show
        #---------------------------------

        bumblebee.turn(-32) # turn towards light show
        bumblebee.straight(-180) # drive backwards to light show
        #back_motor.run_angle(500,-1650)
        #Define a function to run back and front motor simultaneously

        async def front_and_back():
            await multitask(back_motor.run_angle(500,-1650),front_motor.run_angle(400,-250))                                                    
        run_task(front_and_back())  #spin light show and front arm moves down

        #---------------------------------
        # M05, Augmented reality statue
        #---------------------------------

        bumblebee.straight(75) #drive forward a little  
        bumblebee.turn(43) # turn towards M05
        bumblebee.straight(174) #drive towards M05 - from 176 to 174
        # increase the turn speed and acceleration settings
        bumblebee.settings(turn_rate=202,turn_acceleration=910)                      
        bumblebee.turn(87) #turn the base quickly to open the statue

        #---------------------------------
        # M03 - Immersive Experience
        #---------------------------------

        bumblebee.straight(140) #move forwards a bit
        bumblebee.turn(136) # turn towards M03 direction - was 137 beore 
        # Define a function to Move forward and raise the front arm simultaneously  
        ####
        async def forward_and_raise_arm():
            await multitask(front_motor.run_angle(400,250),bumblebee.straight(390)) ## decreased from 410 to 395
        run_task(forward_and_raise_arm())  #move forward while raising the arm up

        bumblebee.turn(90)  #turn the front of the robot to M03
        bumblebee.straight(55)  #drive forward to align to the model
        bumblebee.straight(-40) #drive backwards from the model before activating
        front_motor.run_angle(420,-240,Stop.HOLD) # push immersive experience down
        wait(100) 

        #bumblebee.straight(-80) #drive backwards 
        #front_motor.run_angle(420,250,Stop.COAST) # push immersive experience down

        #bumblebee.turn(-63)
        #bumblebee.settings(straight_acceleration=200)
        #bumblebee.straight(465)
        #bumblebee.straight(-40)
        #bumblebee.turn(20)
        #bumblebee.settings(turn_rate=100,turn_acceleration=100)
        #bumblebee.turn(-30)
        #bumblebee.straight(-25)
        #bumblebee.turn(-50)
        #bumblebee.straight(730)
        #wait(1000)
        #bumblebee.turn(120)
        #bumblebee.straight(200)
        #bumblebee.turn(40)
        #bumblebee.straight(-400)
        #---------------------------------
        #Go Home 
        #---------------------------------

        #increase the speed to save time while heading back to home area
        bumblebee.settings(straight_speed=600,straight_acceleration=1200)
        bumblebee.curve(-600,-110,Stop.COAST) # come back in a curve 
        bumblebee.settings(307,1152,202,910) # Reset the speed settings to default
        