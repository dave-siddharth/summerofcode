from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
#------------------------------------------
# Code for the robot
#------------------------------------------

# Run 7
# Below code is to complete the mission number
# Mission start
# ===============================================
class run8():
#------------------------------------------
# Code for the robot
#------------------------------------------
    def run(self, bumblebee = DriveBase, front_motor = Motor, back_motor = Motor):
        bumblebee.straight(180) #forward 500mm
        bumblebee.turn(-45)
        bumblebee.straight(250)
        bumblebee.turn(-160)
        bumblebee.straight(340)
        bumblebee.turn(-160,Stop.COAST)
        bumblebee.settings(307,1152,202,910) # Reset the speed settings to default