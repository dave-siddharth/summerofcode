from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, run_task, multitask

#------------------------------------------
# Code for the robot
#------------------------------------------
class run2():

    def run(self, bumblebee = DriveBase, front_motor = Motor, back_motor = Motor):
        #------------------------------------------
        # Code for the robot
        #------------------------------------------
        #bumblebee.settings(turn_acceleration=300,turn_rate=200)
        #bumblebee.settings(straight_speed=400,straight_acceleration=600)
        bumblebee.straight(249) # move forward 
        bumblebee.turn(-43) ## turn towards mission 01
        bumblebee.straight(125) # move towards mission 01
        front_motor.run_angle(500,-390) # push down the activator for mission1
        bumblebee.straight(-66)  # move back from mission 1
        front_motor.run_angle(500,390) # pull up the front arm back 

        bumblebee.turn(70) # turn right 
        bumblebee.straight(370) # travel towards the mission 2
        bumblebee.settings(turn_acceleration=200,turn_rate=100)
        bumblebee.turn(-40)  # turn towards mission 2
        bumblebee.settings(straight_speed=200,straight_acceleration=200) # from 250 to 200
        bumblebee.straight(50) # push forward to push the mission 2 once
        bumblebee.turn(5) # slight turn right to avoid bumping 
        bumblebee.straight(95)  # move forward towards Sam the sound engineer from 70 to 95
        front_motor.run_angle(500,-370) # lower down the arm to secure sam
        bumblebee.straight(-95) # move backwards from 95 to 90
        bumblebee.turn(50) # position robot before dropping the audience member
        back_motor.run_angle(400,-250) #drop audience member
        bumblebee.turn(-30) # extra code for second time stage 
        bumblebee.straight(50) #
        bumblebee.settings(straight_speed=800,straight_acceleration=800)
        #increase the speed to move faster to home 
        
        back_motor.run_angle(400,260) # raise bumblebee attachment 
        bumblebee.turn(-45) # turn left before moving back home(-45)
        
        bumblebee.curve(-1000,-40,Stop.COAST) #Use a curve back home

        front_motor.run_angle(500,370) #raise arm to retrieve Sam 
        wait(700)
        front_motor.run_angle(500,-370) # lower the arm down
        
        bumblebee.settings(300,1000,200,800) # Reset the speed settings to default
        #---------------------------------
        #=Code Finished=
        #---------------------------------