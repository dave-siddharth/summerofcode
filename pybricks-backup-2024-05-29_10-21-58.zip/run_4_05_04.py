#Dropping Experts and Audience in different areas

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, run_task, multitask

class run4():
#------------------------------------------
# Code for the robot
#------------------------------------------
    def run(self, bumblebee = DriveBase, front_motor = Motor, back_motor = Motor):

        #------------------------------------------
        # Code for the robot
        #------------------------------------------
        #Drive the robot to drop Emily and audience member in their area
        bumblebee.straight(330) # Drop Emily + audience member using passive basket
        bumblebee.straight(-60) # travel back a bit 
        bumblebee.turn(25) # turn right towards Izzy area
        bumblebee.straight(550) # travel towards area to drop of Izzy 
        front_motor.run_angle(500,400) # lift front arm to release Izzy and audience member 
        bumblebee.straight(-70) # move back a bit 
        bumblebee.turn(61) # point towards the lights audio and concert missions

        #Lower the arm as you move forward - this ensures that the vr statue closes 
        #if it was left open in the first run
        async def forward_and_lower_arm():
            await multitask(front_motor.run_angle(500,-380),bumblebee.straight(900))

        run_task(forward_and_lower_arm()) # using multi tasking here to save time

        bumblebee.turn(-35) # push left to complete VR statue if it was incomplete
        bumblebee.turn(30) # push right again - 2 degrees less 
        bumblebee.straight(200) # head forward towards the 
        bumblebee.turn(42) # turn right to position before dropping Noah + audience memmber
        back_motor.run_angle(400,-280) # drop Noah + audience member from bumblee bee attachment
        bumblebee.settings(turn_rate=100,turn_acceleration=300) # increase speed to save time 
        bumblebee.settings(straight_speed=600,straight_acceleration=1200) # increase speed to save time
        
        #Use multi tasking to raise bumblebee attachment and travel to right side area to save time
        async def curve_and_raise_arm():
            await multitask(front_motor.run_angle(500,380),back_motor.run_angle(400,300),bumblebee.curve(750,55,Stop.COAST))

        run_task(curve_and_raise_arm()) # using multi tasking here to save time
        #go back home while raising bumblebee attachment
        
        bumblebee.straight(60)
        bumblebee.turn(90,Stop.COAST)
        wait(750)
        bumblebee.straight(750)
        bumblebee.straight(-750,Stop.COAST)
        bumblebee.settings(307,1152,202,910) # Reset the speed settings to default