from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, hub_menu, multitask, run_task

class run3():
#------------------------------------------
# Code for the robot
#------------------------------------------
    def run(self, bumblebee = DriveBase, front_motor = Motor, back_motor = Motor):

        #------------------------------------------
        # Code for the robot
        #-----------------------------------------
        #move for 10cm
        #front_motor.run_angle(500,-50) ## rest the arm 
        #front_motor.run_angle(500,55)  ## reset the arm
        bumblebee.settings(straight_speed=300,straight_acceleration=600)
        bumblebee.settings(turn_rate=150,turn_acceleration=400) #was 600 before
        bumblebee.straight(110)
        #turn right 42 degrees
        bumblebee.turn(38) ## reducing from 38 to 32
        #Move towards sound mixer
        bumblebee.straight(320) # reduced from 300 to 295 on 18 May  
        bumblebee.straight(-25)
        #define a function to curve and lift the arm at the same time
        async def curve_and_lift ():
           await multitask(front_motor.run_angle(400,165),bumblebee.curve(72,30))
        
        #bumblebee.settings(turn_rate=50,turn_acceleration=100)
        bumblebee.settings(straight_speed=30,straight_acceleration=60)
        bumblebee.settings(turn_rate=30,turn_acceleration=60) 
        front_motor.run_angle(400,180)
        bumblebee.straight(20)
        wait(250)
        bumblebee.turn(20)
        #run_task(curve_and_lift())
        bumblebee.settings(turn_rate=150,turn_acceleration=600) # reset back to normal
        ##mimic the action of pushing up, moving forward - do this two times to lift
        #the sound mixer
        ##front_motor.run_angle(200,100) #test 120 to 100
        ##bumblebee.straight(10) # reducing this a bit from 15 to 10 
        ##front_motor.run_angle(200,120)
        ##bumblebee.straight(15)
        #Now slowly turn the sound mixer so that the middle control can stay 
        ##bumblebee.settings(turn_rate=40,turn_acceleration=40)
        ##bumblebee.turn(20) # from 16 to 20
        ##wait(750) # was 400 before 

        bumblebee.settings(straight_speed=200,straight_acceleration=800)
        bumblebee.straight(-90)  # reduced on 06 May

        bumblebee.settings(turn_rate=150,turn_acceleration=600)
        bumblebee.turn(30)
        ##Reset the drive base settings to slightly less than the original value

        bumblebee.straight(440) ## 440 from 430
        bumblebee.turn(90)
        bumblebee.straight(85) ## approach the camera -- reduced to 90 from 120
        front_motor.run_angle(200,-170) # Reduced to 140 from 160 degrees 23 march

        #slow speed to move backwards and slow turn
        bumblebee.settings(straight_speed=100,straight_acceleration=600)
        bumblebee.settings(turn_rate=80,turn_acceleration=450)
        bumblebee.straight(-50) # move back from the camera bit - it was-50
        front_motor.run_angle(200,-30)
        bumblebee.turn(71) # Reduced fro 71 to 65

        ##move back and raise the arm at the same time to save some time 
        async def backwards_and_raise_arm():
            await multitask(front_motor.run_angle(500,250),bumblebee.straight(-80))

        run_task(backwards_and_raise_arm())

        #front_motor.run_angle(200,240)
        #bumblebee.straight(-80) # move backwards from the camera

        #set to original value
        bumblebee.settings(straight_speed=200,straight_acceleration=600)
        bumblebee.settings(turn_rate=100,turn_acceleration=450)
        bumblebee.turn(-142) # was 130 earlier       
        bumblebee.straight(415) # Secure Emily in the basket 
        
        #slow down to increase the accuracy of the movement towards the expert
        bumblebee.settings(turn_rate=60,turn_acceleration=100)
        bumblebee.settings(straight_speed=300,straight_acceleration=200)
        bumblebee.turn(-58) # was 54 before
        ##collect and secure Izzy the skateboarder expert
        bumblebee.straight(180) ## Reduced from 190 to 180 on 19 May 
        front_motor.run_angle(500,-200) # Increased the speed from 150 mm/s to 500 mm/s
        bumblebee.straight(-65) # was 40 before
        front_motor.run_angle(150,-70) # keep the slow speed here 

        bumblebee.turn(40) # was 40 before

        bumblebee.settings(straight_speed=600,straight_acceleration=1200)
        #Drive the robot back to left area 
        bumblebee.straight(-350)# was 360
        back_motor.run_angle(400,-250)
        back_motor.run_angle(400,250)
        bumblebee.straight(-240)
        bumblebee.turn(35) ## add this turn to avoid disturbing the camera
        bumblebee.curve(-350,120,Stop.COAST)

        front_motor.run_angle(500,270) #raise arm to retrieve Emily quickly 
        wait(1000) # give some time for technician to pick up Emily
        front_motor.run_angle(500,-270) # lower the arm down
        bumblebee.settings(307,1152,202,910) # Reset the speed settings to default